/**
 * Created by szatpig on 2017/9/26.
 */

export const API_LOGIN = 'login';
export const API_LOGOUT = 'logout';

//用户信息
export const USER_INFO = 'USER_INFO';
export const USER_TOKEN = 'USER_TOKEN';
export const USER_LOGIN_OUT = 'USER_LOGIN_OUT';

//菜单
export const MENU_COLLAPSE = 'MENU_COLLAPSE';
