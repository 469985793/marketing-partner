<template>
    <div class="footer-container">
      苏州瑞翼信息技术有限公司 @copyright 2017
    </div>
</template>

<script>
    export default {
        name: 'foot',
        data () {
            return {
                msg: 'Welcome to Your Vue.js App'
            }
        },
        components: {},
        methods: {},
        computed: {},
        created() {

        }
    }
</script>
