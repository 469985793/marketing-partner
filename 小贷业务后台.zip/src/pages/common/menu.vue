<template>
    <div class="menu-container">
      <el-menu class="el-menu-vertical-demo" :default-active="$route.path"   router :unique-opened="true" :collapse="isCollapse" theme="dark">
        <el-menu-item index="/home/index">
          <i class="el-icon-my-menu">&#xe626;</i>
          <span slot="title">主页</span>
        </el-menu-item>
        <el-submenu index="1">
          <template slot="title">
            <i class="el-icon-my-market">&#xe6bd;</i>
            <span slot="title">订单管理</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/home/markettask">订单列表</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </div>
</template>

<script>
  import { mapState,mapActions } from 'vuex'
  export default {
        name: 'app',
        data () {
            return {
              menuList:[
                {"id":1,"name":"创建活动","code":"create-acitvity","selected":null,"type":1},
                {"id":2,"name":"活动管理","code":"activity-manage","selected":null,"type":1},
                {"id":3,"name":"用户设置","code":"user-config","selected":null,"type":7},
                {"id":4,"name":"分支行设置","code":"branch-bank","selected":null,"type":7},
                {"id":5,"name":"活动分析","code":"activity-analysis","selected":null,"type":1},
                {"id":6,"name":"交易查询","code":"transaction-search","selected":null,"type":3},
                {"id":7,"name":"权益查询","code":"latinos-search","selected":null,"type":3}
              ]
            }
        },
        components: {},
        methods: {
          ...mapActions([
              'menuCollapse'
          ]),
          isMenuCollapse(){
            window.onresize=(()=>{
              let clientWidth=document.body.clientHeight;
              if(clientWidth<1024){
                this.isCollapse=true;
              }
            });
          },
          getMenuHeight(){
            let availableHeight = document.body.clientHeight  - document.querySelector('.header-container').offsetHeight;
            document.querySelector('.content-container').style.height=availableHeight+'px';
            //this.isMenuCollapse();
          },
        },
        computed: {
          ...mapState({
            isCollapse: state=>state.menu.isCollapse
          })

        },
        mounted (){
          this.getMenuHeight();
          window.onresize=(()=>{
            (!!document.querySelector('.content-container'))?this.getMenuHeight():null;
          });
        },
        created() {

        }
    }
</script>

<style lang="scss">

</style>
