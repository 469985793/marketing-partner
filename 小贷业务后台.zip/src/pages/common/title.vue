<template>
    <div class="title-container">
      <span class="collapse-icon" @click="collapseEvent">&#xe61a;</span>
    </div>
</template>

<script>
  import { mapActions} from 'vuex'
  export default {
      name: 'app',
      data () {
          return {
              msg: 'Welcome to Your Vue.js App'
          }
      },
      components: {},
      methods: {
        ...mapActions([
          'menuCollapse'
        ]),
        collapseEvent(){
            this.menuCollapse();
        }
      },
      computed: {

      },
      created() {

      }
  }
</script>

<style lang="scss">

</style>
