<template>
    <div class="header-container">
      <el-row>
        <el-col :xs="24" :sm="4" :md="4" :lg="4"><div class="header-logo" v-text="sysTitle"></div></el-col>
        <el-col :xs="0" :sm="20" :md="20" :lg="20">
          <div class="header-info pull-right">
            <div class="img-area pull-left">
              <img class="logo-img" alt="" :src="userAvatar">
            </div>
            <div class="information-show pull-left"><span v-text="userName">administrator</span></div>
            <i class="icon-loginout pull-left" @click="loginOut">&#xe63a;</i>
          </div>
        </el-col>
      </el-row>
    </div>
</template>

<script>
    import { mapState ,mapActions } from 'vuex'
    export default {
        name: 'head',
        data () {
          return {
            sysTitle:'小额贷款营销平台'
          }
        },
        components: {},
        methods: {
          ...mapActions([
              'userLoginOut'
          ]),
          loginOut(){
            this.$confirm('确定要退出吗?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.$message({
                type: 'success',
                message: '退出成功'
              });
              this.userLoginOut();
              this.$router.push({path:'/login'});
            }).catch(() => {});
          }
        },
        computed: {
          ...mapState({
            userName:state=>state.user.userInfo.identityNo,
            userAvatar:state=>state.user.userInfo.avatar,
          })
        },
        created() {

        }
    }
</script>

<style lang="scss">

</style>
