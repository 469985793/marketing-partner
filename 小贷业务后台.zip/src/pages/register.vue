<template>
    <div class="register-container">

    </div>
</template>

<script>
    export default {
        name: 'app',
        data () {
            return {
                msg: 'Welcome to Your Vue.js App'
            }
        },
        components: {},
        methods: {},
        computed: {},
        created() {

        }
    }
</script>

<style lang="scss">

</style>
