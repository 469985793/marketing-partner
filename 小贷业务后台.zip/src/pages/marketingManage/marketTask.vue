<template>
  <div class="sms-template-container">
    <el-row>
      <el-col>
        <div class="search-container">
          <el-row :gutter="15">
            <el-col :span="4">
              <el-input :span="4" v-model="searchData.key"  placeholder="请输入关键字"></el-input>
            </el-col>
            <el-col :span="4">
              <el-select v-model="addSmsTemplate.operator" :span="4" placeholder="请选择职业" clearable>
                <el-option label="企业主" value="0"></el-option>
                <el-option label="个体户" value="1"></el-option>
                <el-option label="工薪族" value="2"></el-option>
                <el-option label="公务员" value="3"></el-option>
                <el-option label="退休人员" value="4"></el-option>
                <el-option label="其他" value="5"></el-option>

              </el-select>
            </el-col>
            <el-col :span="4">
              <el-select v-model="addSmsTemplate.type" :span="4" placeholder="请选择状态" clearable filterable >
                <el-option label="已联系" value="xiao"></el-option>
                <el-option label="未联系" value="xiao2"></el-option>
              </el-select>
            </el-col>

            <el-col :span="2">
              <el-button :span="4" type="button" class="search-btn" @click="searchEvent">查询</el-button>
            </el-col>
            <el-col :span="2">
              <el-button :span="4" type="success" class="search-add"  @click="dialogFormVisible = true;isEdit=false;">新增</el-button>
            </el-col>
          </el-row>
        </div>
        <div class="search-table">
          <el-table
            ref="multipleTable"
            :data="tableData"
            height="400"
            border
            :default-sort = "{prop: 'id', order: 'descending'}"
            tooltip-effect="dark"
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <el-table-column type="selection" width="45"></el-table-column>
            <el-table-column prop="id" label="#" width="70" show-overflow-tooltip> </el-table-column>
            <el-table-column prop="name" label="姓名" width="80" show-overflow-tooltip> </el-table-column>
            <el-table-column prop="sex" label="性别" width="70" show-overflow-tooltip> </el-table-column>
            <el-table-column prop="vocation" label="职业" width="90" show-overflow-tooltip>
              <template scope="scope">
                <el-tag :type="'success'">{{ scope.row.vocation }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="mobile" label="手机号码" show-overflow-tooltip> </el-table-column>
            <el-table-column prop="loanAmount" label="贷款金额" width="100" show-overflow-tooltip> </el-table-column>
            <el-table-column prop="partner" label="合作方" width="90" show-overflow-tooltip> </el-table-column>
            <el-table-column prop="createTime" label="创建时间" show-overflow-tooltip>
              <template scope="scope">
                <el-icon name="time"></el-icon>
                {{ scope.row.createTime }}
              </template>
            </el-table-column>
            <el-table-column sortable prop="status" label="状态" width="90" show-overflow-tooltip>
              <template scope="scope">
                <el-tag :type="scope.row.status === 1 ? 'success' : 'gray'">{{ scope.row.status === 1 ? '已联系' : '未联系' }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="200" show-overflow-tooltip>
              <template scope="scope">
                <el-button
                  size="small"
                  :type="scope.row.status === 1 ? 'success' : 'gray'"
                  @click="handleStop(scope.$index, scope.row)">{{scope.row.status==1 ? '已联系' : '未联系'}}</el-button>
                <el-button
                  size="small"
                  type="danger"
                  @click="handleDelete(scope.$index, scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <el-row>
          <el-col>
            <div class="search-page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="page.currentPage"
                :page-sizes="[10, 20, 50, 100]"
                :page-size="page.pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="page.total">
              </el-pagination>
            </div>
          </el-col>

        </el-row>

      </el-col>
    </el-row>
  </div>
</template>

<script>
  export default {
    name: 'sysRole',
    data () {
      return {
        searchData:{
          key:''
        },
        page:{
          pageSize:10,
          total:100,
          currentPage: 1
        },
        tableData: [{
          "id":10,
          "name":"马春驰",
          "sex":"男",
          "vocation":"工薪族",
          "mobile":"18262202663",
          "loanAmount":"20w-30w",
          "partner":"有钱途",
          "createTime":"2017-10-09 13:00:00",
          "status":1
        }],
        multipleSelection: [],
        dialogFormVisible: false,
        isEdit:false,
        addSmsTemplate: {
          name:'',
          operator: '',
          type: '',
          content:''
        },
        formLabelWidth: '100px',
        rules: {
          name: [
            { required: true, message: '请输入模板名称', trigger: 'blur' },
          ],
          content: [
            { required: true, message: '请输入模板内容', trigger: 'change' }
          ],
          type: [
            { required: true, message: '请输入模板类型', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      searchEvent(){},
      addEvent(){},
      //状态显示

      //表格处理模块
      toggleSelection(rows) {
        if (rows) {
          rows.forEach(row => {
            this.$refs.multipleTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.multipleTable.clearSelection();
        }
      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },

      handleEdit(formName,index, row) {
        let _self=this;
        _self.isEdit=true;
        this.dialogFormVisible=true;
      },
      handleStop(index, row){
        this.$confirm(row.status==1 ? '此操作将标注【'+row.name+'】未联系用户, 是否继续?' :  '此操作将标注【'+row.name+'】已联系'+'用户, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '禁用成功!'
          });
        }).catch(() => {
          console.log('禁用取消');
        });
      },
      handleDelete(index, row) {
        this.$confirm('此操作将删除【'+row.name+'】用户, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
          this.tableData.splice(index,1);
        }).catch(() => {
          console.log('删除取消');
        });
      },

      //表单提交模块
      submitForm(formName) {
        let _self=this;
        this.$refs[formName].validate((valid) => {
          if (valid) {
            alert('submit!');
          } else {
            return false;
          }
        });
      },

      //分页模块
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      },
      handleChange(val){
        console.log(val)
      },
    },

    computed: {},
    created() {

    }
  }
</script>
