/**
 * Created by szatpig on 2017/9/27.
 */
import { fetch } from '../../util/api'

//用户登录
export const userLogin= (data)=> fetch('/api/login',{
  data,
  'type':'get'
});

export const sendSms = (data,activityId)=>fetch('/api/user/sendSms/'+activityId,{
  data,
  'type':'post'
});

export const mockData = ()=>fetch('/api/login',{
  'type':'get'
});

