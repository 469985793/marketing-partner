<!--suppress ALL -->
<template>
  <div class="rules-container">
    <div class="rules-left">
      <div class="rules-data">
        <el-button :disabled="buttonDisabled"  v-for="( item , index) in dataArray" :key="item.id">{{ item.name }} <i v-show="!buttonDisabled" @click="addData(item)" class="el-icon-plus el-icon--right"></i></el-button>
      </div>
      <div class="rules-contact">
        <el-button :disabled="buttonDisabled" v-for="( item , index) in contactArray" :key="item.id">{{ item.name }} <i v-show="!buttonDisabled" @click="addContact(item)" class="el-icon-plus el-icon--right"></i></el-button>
      </div>
      <div class="rules-event">
        <el-button :disabled="buttonDisabled" v-for="( item , index) in actionArray" :key="item.id">{{ item.name }} <i v-show="!buttonDisabled" @click="addAction(item)" class="el-icon-plus el-icon--right"></i></el-button>
      </div>
    </div>
    <div class="rules-right">
      <div class="market-rules-box">
        <div class="market-rules-cells" :class="{active:selectedIndex==index}" v-for="(item,index) in rulesArray" @click="selectedArea(item,index)">
          <template v-for="(_item,_index) in item.items">
            <div class="cell-arrow" v-show="_item.type=='action'">&#xe60d;</div>
            <div :class="'cell-'+ _item.type" >
              <template v-if="_item.type=='contact'">
                <el-tooltip placement="top" :disabled="!_item.args">
                  <div slot="content">
                    <span v-for="item in _item.args">{{ item }}</span>
                  </div>
                  <el-button :key="_ele.id" v-for="(_ele,_num) in _item.child">{{_ele.name}} <em class="text-red" v-show="_item.args">< 参数 ></em> <i v-show="showCancle(_ele,_index)" @click.stop="remove(_ele,_num,index)" class="el-icon-close el-icon--right"></i></el-button>
                </el-tooltip>
              </template>
              <template v-else>
                <el-tooltip placement="top" :disabled="!(_ele.type=='temp'&& _index==2)" :key="_ele.id" v-for="(_ele,_num) in _item.child">
                  <div slot="content">
                    <p  @click="addNewSource(_ele,index,true)">合并新源至已选择操作区中？</p><br />
                    <p  @click="addNewSource(_ele,index,false)">作为新源进行操作?</p>
                  </div>
                  <el-button>{{_ele.name}} <em class="text-red" v-show="_item.args">< 参数 ></em> <i v-show="showCancle(_ele,_index,index)" @click.stop="remove(_ele,_num,index)" class="el-icon-close el-icon--right"></i></el-button>
                </el-tooltip>
              </template>
            </div>
            <div class="cell-arrow" v-show="_item.type=='contact'">&#xe60d;</div>
          </template>
        </div>
      </div>
      <div class="rules-box">
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'rules',
    data () {
      return {
        dataArray:[{
          id:1,
          name:'远程数据源',
          type:'data'
        },{
          id:2,
          name:'本地数据源',
          type:'data',
          child:[{
            id:21,
            name:"本地用户库"
          },{
            id:22,
            name:"本地黑名单"
          },{
            id:23,
            name:"本地归属地"
          }]
        }],
        contactArray:[
          {id:1,name:"连接",sortFlag:true,type:'contact'},
          {id:2,name:"交集",sortFlag:true,type:'contact'},
          {id:3,name:"并集",sortFlag:true,type:'contact'},
          {id:4,name:"差集",sortFlag:true,type:'contact'},
          {id:5,name:"过滤",sortFlag:true,type:'contact'}],
        actionArray:[
          {id:1,name:"持久化",type:'action',exportType:['success']},
          {id:2,name:"短信发送",type:'action',exportType:["success","fail"]},
          {id:3,name:"微信发送",type:'action',exportType:["success","fail"]}],
        selectedIndex:0,
        rulesArray:[],
        tempArray:[],
        tempButton:[],
        tempParams:'',
        buttonDisabled:false
      }
    },
    components: {},
    methods: {
        addData(_el){
            console.log('addData');
          if(this.rulesArray.length==0){
              this.tempButton.push(_el);
              let tempEl={
                  type:_el.type,
                  child:this.tempButton
              };
              this.tempArray.push(tempEl);
              this.rulesArray.push({
                id:'cell-'+ this.rulesArray.length,
                type:_el.type,
                items:this.tempArray
              });
          }else{
            this.tempArray=this.rulesArray[this.selectedIndex].items;
            this.tempButton=this.rulesArray[this.selectedIndex].items[this.tempArray.length-1].child;
              if(this.tempArray.length==0){

              }else{
                if(this.tempButton.includes(_el)){
                  this.$message({
                    showClose: true,
                    message: '已经添加了该数据源，不可重复添加',
                    type: 'error'
                  });
                  return false;
                }
                this.tempButton.push(_el);
                let tempEl={
                  type:_el.type,
                  child:this.tempButton
                };
                this.rulesArray[this.selectedIndex].items[this.tempArray.length-1].child=this.tempButton;
              }
          }
        },
        addContact(_el){
          if(this.rulesArray.length>0){
            this.tempButton=this.rulesArray[this.selectedIndex].items[this.rulesArray[this.selectedIndex].items.length-1].child;
            if(this.tempButton.length<=1){
              this.$message({
                showClose: true,
                message: '请至少选择两种数据源',
                type: 'error'
              });
              return false;
            }
            this.$prompt('请输入参数', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消'
            }).then(({ value }) => {
              this.tempButton=[];
              this.tempButton.push(_el);
              let tempEl={
                type:_el.type,
                args:value,
                child:this.tempButton
              };
              this.tempArray=this.rulesArray[this.selectedIndex].items;
              this.tempArray.push(tempEl);
              this.rulesArray[this.selectedIndex].items=this.tempArray;

              this.tempArray=this.rulesArray[this.selectedIndex].items;
              this.tempButton=[{
                id:444,
                pid:0,
                name:'tempNewData'+Math.floor(Math.random()*100000),
                type:'temp'
              }];
              tempEl={
                type:'data',
                child:this.tempButton
              };
              this.tempArray.push(tempEl);
              this.rulesArray[this.selectedIndex].items=this.tempArray;
              this.buttonDisabled=true;
            }).catch(() => {
              this.tempButton=[];
              this.tempButton.push(_el);
              let tempEl={
                type:_el.type,
                args:'',
                child:this.tempButton
              };
              this.tempArray=this.rulesArray[this.selectedIndex].items;
              this.tempArray.push(tempEl);
              this.rulesArray[this.selectedIndex].items=this.tempArray;

              this.tempArray=this.rulesArray[this.selectedIndex].items;
              this.tempButton=[{
                id:444,
                pid:0,
                name:'tempNewData'+Math.floor(Math.random()*100000),
                type:'temp'
              }];
              tempEl={
                type:'data',
                child:this.tempButton
              };
              this.tempArray.push(tempEl);
              this.rulesArray[this.selectedIndex].items=this.tempArray;
              this.buttonDisabled=true;
            });
          }else{
            this.$message({
              showClose: true,
              message: '请先选择数据源',
              type: 'error'
            });
          }
        },
        addAction(_el){
          console.log('addAction');
          if( this.rulesArray[this.selectedIndex]){
              this.tempArray=this.rulesArray[this.selectedIndex].items;
              if(this.tempArray[this.tempArray.length-1].child.length!=1){
                this.$message({
                  showClose: true,
                  message: '数据源操作只能唯一，请先合并数据源或删除多余数据源',
                  type: 'error'
                });
                return false;
              }
            this.tempButton=[];
            this.tempButton.push(_el);
            let tempEl={
              type:_el.type,
              child:this.tempButton
            };
            this.tempArray=this.rulesArray[this.selectedIndex].items;
            this.tempArray.push(tempEl);
            this.rulesArray[this.selectedIndex].items=this.tempArray;

            var _self=this;
            _self.tempArray=this.rulesArray[this.selectedIndex].items;
            _self.tempButton=[];
            _el.exportType.forEach((item,_in)=>{
              _self.tempButton.push({
                id:"ch-"+ _in,
                name:'tempActionData'+Math.floor(Math.random()*100000),
                type:"temp",
                pid:_el.id
              })
            });

            tempEl={
              type:_el.type,
              child:this.tempButton
            };
            this.tempArray.push(tempEl);
            this.rulesArray[this.selectedIndex].items=this.tempArray;
            this.buttonDisabled=true;
          }else{
            this.$message({
              showClose: true,
              message: '请先添加数据源或切换至已存在的数据源',
              type: 'error'
            });
          }
          console.log(JSON.stringify(this.rulesArray));
      },
        remove(_el,index,evt){
          this.buttonDisabled=false;
          if(_el.type=='temp'){
              if(this.rulesArray[this.selectedIndex].items.length==3){
                this.rulesArray[this.selectedIndex].items.splice(this.rulesArray[this.selectedIndex].items.length-2,2);
              }else{
                this.rulesArray[this.selectedIndex].items[this.rulesArray[this.selectedIndex].items.length-1].child.splice(index,1);
              }
          }else if(_el.type=='action'){
            this.rulesArray[this.selectedIndex].items.splice(this.rulesArray[this.selectedIndex].items.length-1,1);
            this.buttonDisabled=false;
          }else{
            this.rulesArray[this.selectedIndex].items[this.rulesArray[this.selectedIndex].items.length-1].child.splice(index,1);
          }

          //检测一行数据是否都删除了
          if(this.rulesArray[this.selectedIndex].items.length==1&&this.rulesArray[this.selectedIndex].items[this.rulesArray[this.selectedIndex].items.length-1].child.length==0){
            this.rulesArray.splice(this.selectedIndex,1);
            this.selectedIndex=0;
          }
          if(this.rulesArray[this.selectedIndex].items.length==0){
            this.rulesArray.splice(this.selectedIndex,1);
            this.selectedIndex=0;
          }
        },
        showCancle(_el,_index,index){
          if(index==this.selectedIndex && _index==this.rulesArray[this.selectedIndex].items.length-1 ){
            /*if(_el.type=='temp' && this.rulesArray[this.selectedIndex].items[this.rulesArray[this.selectedIndex].items.length-1].child.length>1){
              return false;
            }*/
            return true;
          }
          return false;
        },
        addNewSource(_el,index,flag){
            this.tempButton=[];
            this.tempArray=[];
            if(flag && this.rulesArray.length >1){
                this.tempArray=this.rulesArray[this.selectedIndex].items;
                this.tempButton=this.tempArray[this.tempArray.length-1].child;
                if(index==this.selectedIndex){
                  this.$message({
                    showClose: true,
                    message: '请选择其他操作区后再合并源至其他操作区',
                    type: 'error'
                  });
                  return false;
                }
                if(this.tempArray.length>1){
                  this.$message({
                    showClose: true,
                    message: '不得向已输出源进行源添加！',
                    type: 'error'
                  });
                  return false;
                }
                if(this.tempButton.includes(_el)){
                  this.$message({
                    showClose: true,
                    message: '已经添加了该数据源，不可重复添加',
                    type: 'error'
                  });
                  return false;
                }
                this.tempButton.push(_el);
                this.tempArray[this.tempArray.length-1].child=this.tempButton;
                this.rulesArray[this.selectedIndex].items=this.tempArray;
                this.buttonDisabled=false;
            }else{
                this.tempButton.push(_el);
                this.tempArray.push({
                  type:_el.type,
                  child:this.tempButton
                });
                this.rulesArray.push({
                  id:'cell-'+ this.rulesArray.length,
                  type:_el.type,
                  items:this.tempArray
                });
                this.selectedIndex=this.rulesArray.length-1;
                this.buttonDisabled=false;
                if(this.rulesArray.length<=2){
                  this.$message({
                    showClose: true,
                    message: '无目标操作区，已自动为您创建新源',
                    type: 'warning'
                  });
                }
            }
          //}else{
/*            this.tempArray=this.rulesArray[this.selectedIndex].items;
            this.tempButton=this.rulesArray[this.selectedIndex].items[this.tempArray.length-1].child;
            if(this.tempArray.length==0){

            }else{
              if(this.tempButton.includes(_el)){
                this.$message({
                  showClose: true,
                  message: '已经添加了该数据源，不可重复添加',
                  type: 'error'
                });
                return false;
              }
              this.tempButton.push(_el);
              let tempEl={
                type:_el.type,
                child:this.tempButton
              };
              this.rulesArray[this.selectedIndex].items[this.tempArray.length-1].child=this.tempButton;
            }*/
          //}
        },
        selectedArea(_el,index){
            this.selectedIndex=index;
            if(_el.items.length==3){
                this.buttonDisabled=true;
            }else{
              this.buttonDisabled=false;
            }
        }
    },
    computed: {
    },
    created() {

    }
  }
</script>

<style lang="scss">
  .rules-container{
    .rules-left{
      float: left;
      height: 550px;
      width:240px;
      border-right: 1px solid #eee;
      div[class^="rules-"]{
        border-bottom: 1px solid #eee;
        padding: 15px;
        &:last-child{
          border-bottom: 0;
        }
      }
      button{
        display: block;
        margin-bottom: 10px;
        margin-left: 0px;
        i{
          font-size: 11px;
        }
      }
    }
    .rules-right{
      width: 100%;
      height: 550px;
      padding: 0 0 0 240px;
      box-sizing: border-box;
      .market-rules-box{
        width:100%;
        height: 100%;
        padding: 20px;
        overflow-x: auto;
        .market-rules-cells{
          box-sizing: border-box;
          overflow: hidden;
          padding: 15px 15px 5px 15px;
          margin-top: 19px;
          margin-bottom: 0;
          border: 1px dashed #D3DCE6;
          display: flex;
          display: -webkit-flex;
          -webkit-flex-flow: row nowrap;
          flex-flow:row nowrap ;
          -webkit-justify-content: flex-start;
          justify-content:flex-start;
          -webkit-align-items:center;
          align-items:center;
          position: relative;
          overflow-x: auto;
          &:first-child{
            margin-top: 0;
          }
          &.active{
            border: 1px dashed #13CE66;
            box-sizing: border-box;
            &:before{
              content: '';
              display: block;
              position:absolute;
              top:0;
              left: 0;
              width:0;
              height: 0;
              border-top:27px solid #13CE66;
              border-right:27px solid transparent;
            }
          }
        }
        [class^='cell-']{
          float: left;
          width:auto;

        }
      }
      button{
        display: block;
        margin-bottom: 10px;
        margin-left: 0px;
        margin-right: 10px;
        position: relative;
        i{
          font-size: 11px;
        }
        &:hover{
          color: #1f2d3d;
          border-color: #c4c4c4;
        }
      }
    }
  }
</style>
